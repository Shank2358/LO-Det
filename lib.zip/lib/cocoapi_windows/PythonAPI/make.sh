# install pycocotools locally
python setup.py build_ext --inplace
 
# install pycocotools to the Python site-packages
python setup.py build_ext install